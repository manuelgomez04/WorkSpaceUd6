package ejercicio;

public class FormatoMatriculaException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FormatoMatriculaException() {

	}

	public FormatoMatriculaException(String s) {
		super(s);
	}
}
