package ejercicio;

public class PrecioNegativoException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PrecioNegativoException() {

	}

	public PrecioNegativoException(String s) {
		super(s);
	}
}
