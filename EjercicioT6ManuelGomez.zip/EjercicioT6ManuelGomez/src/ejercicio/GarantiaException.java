package ejercicio;

public class GarantiaException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GarantiaException() {

	}

	public GarantiaException(String s) {
		super(s);
	}
}
